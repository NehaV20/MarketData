# API_BASE_URL = "http://api.aryafingroup.in:11025/md-api"
# AUTH_BASE_URL = "http://api.aryafingroup.in:11025/api-server"
# Web_Base_URL = f"ws://api.aryafingroup.in:11025/md-streaming/ws?key="


# UAT
# AUTH_BASE_URL = "http://uat.quantxpress.com/api_gateway/v1"
# API_BASE_URL = "http://uat.quantxpress.com/md-api"

# Web_Base_URL = f"ws://uat.quantxpress.com/md-streaming/ws?key="

# REDIS_URL = "redis://localhost:6379" 
# INSTRUMENT_URL = "http://uat.quantxpress.com/v1/api/instruments/gz/download"


# Production
AUTH_BASE_URL = "http://180.179.156.97:9443/api_gateway/v1/"
API_BASE_URL = "http://180.179.156.97:9443/md-api"

Web_Base_URL = f"ws://180.179.156.97:9443/md-streaming/ws?key="

REDIS_URL = "redis://localhost:6379" 
INSTRUMENT_URL = "http://uat.quantxpress.com/v1/api/instruments/gz/download"
